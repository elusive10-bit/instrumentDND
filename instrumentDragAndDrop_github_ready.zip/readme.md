# Instrument Drag and Drop app

please clone the sourcecode or download the zip, extract and run the index HTML.

## Technologies included:
1. Plain HTML, CSS, and Javascript (didn't use any framework to deepen my knowledge on these)
* could make another version of this project using frameworks in later versions

## features include:
1. Drag and Drop 
1. Sound on correct drop and other events
1. Theme Switcher

## Art assets and audio assets made by myself created/edited on inkscape(art assets) and lmms(audio assets)

### Mobile drag and drop is still not functional, 
### still thinking of a way to implement that
